import json,sys
from pathlib import Path
scene=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print(scene["scene_id"],scene["statistics"])
for tower in scene["towers"]:
    print(tower["id"],tower["source_object_id"],tower["longitude"],tower["latitude"])
