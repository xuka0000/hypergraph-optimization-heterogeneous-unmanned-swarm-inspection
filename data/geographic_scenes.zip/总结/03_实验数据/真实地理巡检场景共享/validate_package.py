"""Portable source/coordinate/link audit; no network or optimization calls."""
import argparse, hashlib, json, math, sys, xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
import numpy as np
import networkx as nx
from jsonschema import Draft202012Validator
from pyproj import Transformer
from scipy.spatial import Delaunay

def read(p):
    return json.loads(p.read_text(encoding='utf-8'),parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(condition,message):
    if not condition:raise AssertionError(message)

def schema():
    point=dict(type='object',required=['id','longitude','latitude'],properties=dict(id={'type':'string'},longitude={'type':'number','minimum':-180,'maximum':180},latitude={'type':'number','minimum':-90,'maximum':90},easting_m={'type':'number'},northing_m={'type':'number'}))
    tower=dict(point,required=point['required']+['source_object_id','source_system','actual_height_m','source_ids'],properties={**point['properties'],'actual_height_m':{'type':['number','null']},'source_ids':{'type':'array','items':{'type':'string'},'minItems':1}})
    parameter=dict(type='object',required=['key','value','unit','evidence_kind','source_ids','status'],properties=dict(key={'type':'string'},unit={'type':'string'},evidence_kind={'type':'string'},source_ids={'type':'array','items':{'type':'string'}}))
    properties={k:{'type':'array'} for k in ['power_nodes','power_ways','power_segments','substations','stops','bases','inspection_tasks','transfer_waypoints','tower_routes','construction','field_provenance','missing_parameters','source_catalog']}
    properties.update(schema_version={'const':'1.0.0'},scene_id={'type':'string'},coordinate_reference={'type':'object','required':['geographic','projected','xy_unit','vertical_datum']},towers={'type':'array','minItems':1,'items':tower},parameters={'type':'array','items':parameter},roads={'type':'object'},terrain={'type':'object'},statistics={'type':'object'})
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Geographic inspection scene interchange 1.0.0','type':'object','required':list(properties),'properties':properties}

def walk(x):
    if isinstance(x,dict):
        yield x
        for v in x.values():yield from walk(v)
    elif isinstance(x,list):
        for v in x:yield from walk(v)

def validate(root):
    cat=read(root/'catalog.json');validator=Draft202012Validator(read(root/'scene.schema.json'))
    source_count=0
    for s in cat['source_catalog']:
        if s.get('package_path'):
            check(sha(root/s['package_path'])==s['sha256'],'source hash '+s['id']);source_count+=1
    scenes={};results=[]
    for c in cat['scenes']:
        p=root/c['file'];check(sha(p)==c['sha256'],'scene hash '+c['id']);s=read(p);validator.validate(s);scenes[s['scene_id']]=s
        refs={r['id'] for r in s['source_catalog']};points=[]
        for row in walk(s):
            if 'source_ids' in row:check(set(row['source_ids'])<=refs,'unresolved source '+str(row['source_ids']))
            if all(k in row for k in ('longitude','latitude','easting_m','northing_m')):points.append([row[k] for k in ('longitude','latitude','easting_m','northing_m')])
        xy=np.asarray(points);tr=Transformer.from_crs(4326,s['coordinate_reference']['projected'],always_xy=True)
        a,b=tr.transform(xy[:,0],xy[:,1]);error=float(np.max(np.hypot(a-xy[:,2],b-xy[:,3])))
        check(error<1e-6,'projection '+s['scene_id'])
        ids={x['id'] for x in s['towers']};check(len(ids)==len(s['towers']),'duplicate tower id')
        check(len({x['source_object_id'] for x in s['towers']})==len(ids),'duplicate source tower')
        pn={x['id'] for x in s['power_nodes']};rn={x['id'] for x in s['roads']['nodes']}
        for seg in s['power_segments']:check(seg['tail'] in pn and seg['head'] in pn,'power dangling link')
        for seg in s['roads'].get('edges',[])+s['roads'].get('segments',[]):
            check(seg['tail'] in rn and seg['head'] in rn,'road dangling link');check(seg['length_m']>0,'nonpositive road')
        counts=Counter(x['tower_id'] for x in s['inspection_tasks'])
        for t in s['towers']:
            if s['scene_kind']!='real_geographic_candidate':
                check(counts[t['id']]==9,'photo count');check(set(t['photo_task_ids'])=={x['id'] for x in s['inspection_tasks'] if x['tower_id']==t['id']},'photo links')
            else:check(t['ground_elevation_m'] is None and t['photo_task_ids'] is None,'unknown geometry')
        for field,items in [('towers',s['towers']),('power_nodes',s['power_nodes']),('power_segments',s['power_segments']),('road_nodes',s['roads']['nodes']),('road_edges',s['roads'].get('edges',[])),('photo_tasks',s['inspection_tasks']),('candidate_stops',s['stops']),('terrain_samples',s['terrain']['samples'])]:check(s['statistics'][field]==len(items),'count '+field)
        # Tower coordinates checked directly against retained raw source, independent of exporter output.
        sr={x['id']:x for x in s['source_catalog']}
        if s['scene_id'].startswith('ubeda_author'):
            raw=ET.parse(root/sr['AUTHOR_TOWERS']['package_path']).getroot();coords=[]
            for el in raw.findall('.//{http://www.opengis.net/kml/2.2}coordinates'):coords.extend(tuple(map(float,t.split(',')[:2])) for t in el.text.split())
            check(all((t['longitude'],t['latitude']) in coords for t in s['towers']),'KML coordinates')
        else:
            source=sr['OSM_UBEDA'] if s['scene_id'].startswith('ubeda') else sr['OSM_'+s['scene_id']+'_power']
            f=root/source['package_path']
            raw=ET.parse(f).getroot() if f.suffix=='.xml' else read(f)
            nodes={x.attrib['id']:(float(x.attrib['lon']),float(x.attrib['lat'])) for x in raw.findall('node')} if f.suffix=='.xml' else {str(x['id']):(x['lon'],x['lat']) for x in raw['elements'] if x['type']=='node'}
            check(all(nodes[t['source_object_id']]==(t['longitude'],t['latitude']) for t in s['towers']),'OSM coordinates')
        outside=None;strong=None
        if s['terrain']['samples']:
            samples=s['terrain']['samples'];xs,ys=tr.transform([r['location']['lng'] for r in samples],[r['location']['lat'] for r in samples]);hull=Delaunay(np.column_stack([xs,ys]))
            assets=[[t['easting_m'],t['northing_m']] for t in s['towers']+s['inspection_tasks']]+[t['xy_m'] for t in s['stops']]
            outside=int(np.sum(hull.find_simplex(assets)<0));check(outside==0,'terrain extrapolation')
            route_nodes=set(s['roads'].get('routing_graph',{}).get('node_ids',rn))
            check(route_nodes<=rn,'routing nodes belong to retained map')
            g=nx.DiGraph();g.add_nodes_from(route_nodes);g.add_edges_from((e['tail'],e['head']) for e in s['roads']['edges']);strong=nx.is_strongly_connected(g);check(strong,'road strong connectivity')
            if 'routing_graph' in s['roads']:
                state=nx.DiGraph();state.add_nodes_from(e['id'] for e in s['roads']['edges']);state.add_edges_from(s['roads']['routing_graph']['allowed_edge_transitions'])
                check(nx.is_strongly_connected(state),'turn-aware strong connectivity')
            for stop in s['stops']:check(stop['osm_node_id'] in rn,'stop road node')
        if s['scene_id'].startswith('ubeda_osm'):
            for route in s['tower_routes']:
                tasks=[x for x in s['inspection_tasks'] if x['tower_id']==route['tower_id']]
                check(abs(sum(x.get('incoming_seconds',0) for x in route['points'])+sum(x['effective_service_seconds'] for x in tasks)-300)<1e-7,'tower timing')
            for curve in s['charging_profiles']['sensitivity_profiles']:
                check(abs(curve['charge_time_knots_seconds'][2]-curve['charge_time_knots_seconds'][1]-1800)<1e-7,'partial charge source')
        if s['scene_id'] in {'rommerskirchen','brauweiler','villevaude'}:
            # Separate determinant calculation checks the strict intersection count.
            by={n['id']:np.array([n['easting_m'],n['northing_m']]) for n in s['power_nodes']}
            segments={tuple(sorted([e['tail'],e['head']])) for e in s['power_segments']}
            lines=[(by[a],by[b]) for a,b in segments];locations=set()
            cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
            for i,(a,b) in enumerate(lines):
                r=b-a
                for c,d in lines[i+1:]:
                    if any(np.array_equal(x,y) for x in (a,b) for y in (c,d)):continue
                    v=d-c;den=cross(r,v)
                    if abs(den)<1e-12:continue
                    t=cross(c-a,v)/den;u=cross(c-a,r)/den
                    if 0<t<1 and 0<u<1:
                        q=a+t*r;locations.add((round(float(q[0]),3),round(float(q[1]),3)))
            saved={(round(x['easting_m'],3),round(x['northing_m'],3)) for x in s['geometric_crossings']}
            check(locations==saved,'independent intersection locations')
        results.append(dict(scene_id=s['scene_id'],status='PASS',tower_count=len(ids),photo_count=len(s['inspection_tasks']),projected_points_checked=len(points),max_projection_error_m=error,source_tower_coordinates_exact=True,terrain_assets_outside_hull=outside,road_strongly_connected=strong,historical_crossings=s.get('historical_crossing_count'),current_crossings=s['statistics'].get('geometric_crossings_outside_mapped_substations')))
    identity=lambda key:{t['source_object_id'] for t in scenes[key]['towers']}
    check(identity('ubeda_author_006')<identity('ubeda_author_027'),'prototype subset')
    check(identity('ubeda_osm_060')<identity('ubeda_osm_100')<identity('ubeda_osm_150'),'scale nesting')
    overlap=len(identity('rommerskirchen')&identity('brauweiler'));check(overlap==14,'German overlap')
    return dict(status='PASS',scene_count=len(scenes),tower_records=sum(len(s['towers']) for s in scenes.values()),photo_records=sum(len(s['inspection_tasks']) for s in scenes.values()),source_hashes_verified=source_count,scene_hashes_verified=len(scenes),german_shared_tower_ids=overlap,nested_scenes_are_not_independent=True,results=results,scope='Source, schema, coordinates and entity consistency only; no solver feasibility or field certification',known_differences=['Rommerskirchen current proper UTM intersections outside mapped station polygons=23; historical summary=24; old derived files and implementation unavailable.'])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--write-schema',action='store_true');args=ap.parse_args()
    if args.write_schema:(args.root/'scene.schema.json').write_text(json.dumps(schema(),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    result=validate(args.root);(args.root/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
